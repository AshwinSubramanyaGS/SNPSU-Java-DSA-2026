public class Solution {
    public static boolean isPalindrome(String s) {
        // implement here
        return false;
    }
}