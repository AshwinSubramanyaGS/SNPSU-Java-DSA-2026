public class Solution {
    public static int kthSmallest(int[] nums, int k) {
        // implement here
        return 0;
    }
}