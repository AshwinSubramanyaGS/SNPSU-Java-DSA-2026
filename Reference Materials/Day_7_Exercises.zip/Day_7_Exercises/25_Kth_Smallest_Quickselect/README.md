# K-th Smallest Using Quickselect

Given an unsorted integer array and valid k (1-indexed), return the k-th smallest value using quickselect.

Expected average time: O(n). Do not fully sort the array.

Example: [7,10,4,3,20,15], k=3 -> 7.

## Method
`Solution.int kthSmallest(int[] nums, int k)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
