# N-Queens Solver

Place n queens on an n x n chessboard so that no two queens attack each other. Return the number of valid solutions using backtracking.

A queen attacks another queen when they share a row, column, or diagonal.

Constraints: 1 <= n <= 10.

Use the exercise to practice recursive decision-making and pruning.

## Method
`Solution.int totalNQueens(int n)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
