public class Solution {
    public static int totalNQueens(int n) {
        // implement here
        return 0;
    }
}