import java.util.*;

public class Solution {
    public static int fibonacci(int n) {
        // implement here
        return 0;
    }
}