public class Solution {
    public static long countInversions(int[] nums) {
        // implement here
        return 0L;
    }
}