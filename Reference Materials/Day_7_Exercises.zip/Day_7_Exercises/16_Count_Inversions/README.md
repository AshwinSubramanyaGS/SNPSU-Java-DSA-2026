# Count Inversions Using Merge Sort

Count the number of inversions in an integer array. An inversion is a pair `(i,j)` such that i < j and nums[i] > nums[j].

Use a merge-sort-based solution with O(n log n) time. Do not compare every pair directly.

## Method
`Solution.long countInversions(int[] nums)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
