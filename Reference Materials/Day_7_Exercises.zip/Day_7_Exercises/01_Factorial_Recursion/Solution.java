public class Solution {
    public static int factorial(int n) {
        // implement here
        return 0;
    }
}