import java.util.*;

public class Solution {
    public static List<String> generateParentheses(int n) {
        // implement here
        return new ArrayList<>();
    }
}