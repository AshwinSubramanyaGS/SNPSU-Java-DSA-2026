# Generate Balanced Parentheses

Given n pairs of parentheses, generate every valid balanced sequence using backtracking.

The output order does not matter.

Example: n=3 -> 5 sequences.

## Method
`Solution.List<String> generateParentheses(int n)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
