import java.util.*;

public class Solution {
    public static List<String> letterCombinations(String digits) {
        // implement here
        return new ArrayList<>();
    }
}