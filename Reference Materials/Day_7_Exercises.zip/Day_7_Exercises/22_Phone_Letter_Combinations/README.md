# Phone Number Letter Combinations

Given a string containing digits 2-9, return all possible letter combinations based on the telephone keypad mapping. Use backtracking.

The output order does not matter. For an empty input, return an empty list.

## Method
`Solution.List<String> letterCombinations(String digits)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
