# Search on Answer: Minimum Eating Speed

You are given piles of bananas and h hours. At speed k, a worker eats k bananas per hour from one pile; if a pile has fewer than k bananas, the remaining bananas still consume one full hour.

Return the minimum integer k that allows all bananas to be eaten within h hours.

Use binary search over the answer space rather than searching array indices.

Example: [3,6,7,11], h=8 -> 4.

## Method
`Solution.int minEatingSpeed(int[] piles, int h)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
