public class Solution {
    public static void sortColors(int[] nums) {
        // implement here
    }
}