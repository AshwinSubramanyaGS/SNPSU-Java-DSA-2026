# Dutch National Flag Partition

Given an array containing only 0, 1 and 2, sort it in-place in one pass using constant extra space.

Use the low, mid, and high pointers from the Dutch National Flag algorithm. Do not call a library sort.

## Method
`Solution.void sortColors(int[] nums)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
