public class Solution {
    public static boolean subsetSum(int[] nums, int target) {
        // implement here
        return false;
    }
}