# Subset Sum Decision

Given an array of positive integers and a target, return true if some subset sums exactly to target. Each input value may be used at most once.

Solve using recursion/backtracking with pruning where appropriate.

Example: [3,34,4,12,5,2], target=9 -> true.

## Method
`Solution.boolean subsetSum(int[] nums, int target)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
