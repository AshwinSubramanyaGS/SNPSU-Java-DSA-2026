public class Solution {
    public static int lastOccurrence(int[] nums, int target) {
        // implement here
        return -1;
    }
}