public class Solution {
    public static void merge(int[] a, int m, int[] b, int n) {
        // implement here
    }
}