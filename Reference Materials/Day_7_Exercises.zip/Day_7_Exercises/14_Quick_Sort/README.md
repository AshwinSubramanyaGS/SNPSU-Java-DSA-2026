# Quick Sort

Sort an integer array in ascending order using quick sort.

Requirements:
- Choose a pivot and partition the array recursively.
- Do not use library sorting.
- Aim for average O(n log n) time and in-place sorting.

## Method
`Solution.int[] quickSort(int[] nums)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
