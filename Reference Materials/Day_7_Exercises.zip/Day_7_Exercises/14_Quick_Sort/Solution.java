public class Solution {
    public static int[] quickSort(int[] nums) {
        // implement here
        return nums;
    }
}