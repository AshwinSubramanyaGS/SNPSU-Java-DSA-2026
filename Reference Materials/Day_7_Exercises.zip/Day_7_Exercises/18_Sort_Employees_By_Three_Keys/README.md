# Sort Employees by Three Keys

Create an Employee model and sort employees using a custom comparator with three keys in this exact priority order:
1. Department ascending
2. Salary descending
3. Name ascending

Return the sorted list. Use `Comparator` composition and do not modify the original objects.

## Method
`Solution.List<Employee> sortEmployees(List<Employee> employees)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.

Expected ordering for the main demonstration:
`Anu|HR|85000`, `Amit|HR|85000`, `Bob|IT|120000`, `Cara|IT|120000`, `Zara|IT|90000`.
