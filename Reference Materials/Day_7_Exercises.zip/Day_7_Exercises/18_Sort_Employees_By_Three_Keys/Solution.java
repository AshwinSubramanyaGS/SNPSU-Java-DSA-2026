import java.util.*;

public class Solution {
    static class Employee {
        String name;
        String department;
        int salary;

        Employee(String name, String department, int salary) {
            this.name = name;
            this.department = department;
            this.salary = salary;
        }

        @Override
        public String toString() {
            return name + "|" + department + "|" + salary;
        }
    }

    public static List<Employee> sortEmployees(List<Employee> employees) {
        // implement here
        return new ArrayList<>();
    }
}