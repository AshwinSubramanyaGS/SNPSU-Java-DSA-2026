import java.util.*;

public class Main {
    static int passed = 0;

    public static void main(String[] args) {
        char[][] b1={{'A','B','C','E'},{'S','F','C','S'},{'A','D','E','E'}};
        runTest(1, () -> Solution.exist(b1, "ABCCED"), true, x -> Boolean.TRUE.equals(x));
        char[][] b2={{'A','B','C','E'},{'S','F','C','S'},{'A','D','E','E'}};
        runTest(2, () -> Solution.exist(b2, "ABCB"), false, x -> Boolean.FALSE.equals(x));
        char[][] b3={{'A'}};
        runTest(3, () -> Solution.exist(b3, "A"), true, x -> Boolean.TRUE.equals(x)); // EDGE CASE
        System.out.println(passed + " / 3 cases cleared");
    }

    interface Checker { boolean matches(Object actual); }
    interface ThrowingSupplier { Object get() throws Throwable; }
    static void runTest(int n, ThrowingSupplier supplier, Object expected, Checker checker) {
        try {
            Object actual = supplier.get();
            boolean ok = checker.matches(actual);
            System.out.println("testcase " + n + ": " + (ok ? "pass" : "fail"));
            if (!ok) {
                System.out.println("expected output: " + display(expected));
                System.out.println("your output: " + display(actual));
            }
            if (ok) passed++;
        } catch (Throwable e) {
            System.out.println("testcase " + n + ": fail");
            System.out.println("expected output: " + display(expected));
            System.out.println("your output: exception " + e.getClass().getSimpleName());
        }
    }
    static String display(Object x) {
        if (x instanceof int[]) return Arrays.toString((int[]) x);
        if (x instanceof long[]) return Arrays.toString((long[]) x);
        if (x instanceof Object[]) return Arrays.deepToString((Object[]) x);
        return String.valueOf(x);
    }
}
