# Word Search Backtracking

Given a 2D character board and a word, determine whether the word exists by moving up/down/left/right. A cell may be used at most once in one path.

Use recursive DFS/backtracking. Do not build all paths in advance.

## Method
`Solution.boolean exist(char[][] board, String word)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
