public class Solution {
    public static boolean exist(char[][] board, String word) {
        // implement here
        return false;
    }
}