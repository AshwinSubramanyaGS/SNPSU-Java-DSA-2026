import java.util.*;

public class Solution {
    public static List<List<Integer>> combinationSum(int[] candidates, int target) {
        // implement here
        return new ArrayList<>();
    }
}