# Combination Sum

Given an array of distinct positive integers `candidates` and a positive target, return all unique combinations whose values sum to target. A candidate may be used unlimited times.

The output order does not matter; combinations such as [2,2,3] and [3,2,2] represent the same answer.

Example: candidates=[2,3,6,7], target=7 -> [2,2,3], [7].

## Method
`Solution.List<List<Integer>> combinationSum(int[] candidates, int target)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
