public class Solution {
    public static long climbWays(int n) {
        // implement here
        return 0L;
    }
}