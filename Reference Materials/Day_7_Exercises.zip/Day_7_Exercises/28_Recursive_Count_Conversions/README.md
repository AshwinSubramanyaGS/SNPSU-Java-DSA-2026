# Recursive Count of Ways to Climb

A staircase has n steps. You may climb either 1 or 2 steps at a time. Return the number of distinct ways to reach exactly step n using recursion with memoization.

Define ways(0)=1 and ways(1)=1.

This is an interview-style recursion problem and should avoid exponential recomputation.

## Method
`Solution.long climbWays(int n)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
