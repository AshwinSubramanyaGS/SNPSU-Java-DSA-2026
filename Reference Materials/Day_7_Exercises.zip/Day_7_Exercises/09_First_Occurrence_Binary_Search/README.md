# First Occurrence With Binary Search

Given a sorted array that may contain duplicates, return the index of the first occurrence of target. Return -1 if it does not exist.

The solution must run in O(log n) time.

## Method
`Solution.int firstOccurrence(int[] nums, int target)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
