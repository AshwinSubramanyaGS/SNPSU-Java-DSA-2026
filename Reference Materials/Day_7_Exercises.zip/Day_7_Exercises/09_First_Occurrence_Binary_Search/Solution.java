public class Solution {
    public static int firstOccurrence(int[] nums, int target) {
        // implement here
        return -1;
    }
}