public class Solution {
    public static int binarySearch(int[] nums, int target) {
        // implement here
        return -1;
    }
}