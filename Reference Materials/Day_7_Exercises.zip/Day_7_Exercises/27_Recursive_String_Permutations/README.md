# Recursive String Permutations

Given a string of distinct lowercase letters, return all permutations using recursion by choosing one character at each level.

The output order does not matter.

Do not use `Collections.permute` or library helpers.

## Method
`Solution.List<String> permutations(String s)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
