import java.util.*;

public class Solution {
    public static List<String> permutations(String s) {
        // implement here
        return new ArrayList<>();
    }
}