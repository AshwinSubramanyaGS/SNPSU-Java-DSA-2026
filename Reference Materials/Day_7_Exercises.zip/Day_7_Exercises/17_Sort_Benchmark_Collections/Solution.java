import java.util.*;

public class Solution {
    public static long[] benchmark(int size, int seed) {
        // implement here
        return new long[]{0L, 0L};
    }

    public static void sortInPlace(List<Integer> data) {
        // implement your own sorting algorithm here
    }
}