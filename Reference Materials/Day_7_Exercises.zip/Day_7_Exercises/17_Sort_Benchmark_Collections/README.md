# Benchmark Custom Sort Against Collections

Implement a method that benchmarks your own sorting approach against `Collections.sort` on the same generated integer data. Return the measured times as `[customNanos, collectionsNanos]`.

Requirements:
- Your custom sort must be implemented inside `Solution.sortInPlace`.
- `benchmark(int size, int seed)` should generate deterministic data, clone it, time both approaches, and verify both results are equal.
- Do not rely on exact timing numbers in tests; the harness only checks that both timings are non-negative and that the benchmark internally verifies correctness.

## Method
`Solution.long[] benchmark(int size, int seed)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
