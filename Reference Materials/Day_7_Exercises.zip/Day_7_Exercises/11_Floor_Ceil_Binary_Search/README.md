# Floor and Ceil in a Sorted Array

Given a sorted array and target, return an int array `[floor, ceil]`.

- floor = greatest value <= target; use -1 if no such value exists.
- ceil = smallest value >= target; use -1 if no such value exists.

Use binary search. Example: [1,3,5,7], target=4 -> [3,5].

## Method
`Solution.int[] floorCeil(int[] nums, int target)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
