public class Solution {
    public static int[] floorCeil(int[] nums, int target) {
        // implement here
        return new int[]{-1, -1};
    }
}