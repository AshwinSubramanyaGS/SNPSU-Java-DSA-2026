public class Solution {
    public static void solveSudoku(char[][] board) {
        // implement here
    }
}