import java.util.*;

public class Main {
    static int passed = 0;

    public static void main(String[] args) {
        char[][] board1 = new char[][]{{'5','3','.','.','7','.','.','.','.'},{'6','.','.','1','9','5','.','.','.'},{'.','9','8','.','.','.','.','6','.'},{'8','.','.','.','6','.','.','.','3'},{'4','.','.','8','.','3','.','.','1'},{'7','.','.','.','2','.','.','.','6'},{'.','6','.','.','.','.','2','8','.'},{'.','.','.','4','1','9','.','.','5'},{'.','.','.','.','8','.','.','7','9'}};
        runTest(1, () -> { Solution.solveSudoku(board1); return isSolved(board1); }, true, x -> Boolean.TRUE.equals(x));
        char[][] board2 = new char[][]{{'.','.','9','7','4','8','.','.','.'},{'7','.','.','.','.','.','.','.','.'},{'.','2','.','1','.','9','.','.','.'},{'.','.','7','.','.','.','2','4','.'},{'.','6','4','.','1','.','5','9','.'},{'.','9','8','.','.','.','3','.','.'},{'.','.','.','8','.','3','.','2','.'},{'.','.','.','.','.','.','.','.','6'},{'.','.','.','2','7','5','9','.','.'}};
        runTest(2, () -> { Solution.solveSudoku(board2); return isSolved(board2); }, true, x -> Boolean.TRUE.equals(x));
        char[][] board3 = new char[][]{{'5','3','4','6','7','8','9','1','2'},{'6','7','2','1','9','5','3','4','8'},{'1','9','8','3','4','2','5','6','7'},{'8','5','9','7','6','1','4','2','3'},{'4','2','6','8','5','3','7','9','1'},{'7','1','3','9','2','4','8','5','6'},{'9','6','1','5','3','7','2','8','4'},{'2','8','7','4','1','9','6','3','5'},{'3','4','5','2','8','6','1','7','9'}};
        runTest(3, () -> { Solution.solveSudoku(board3); return isSolved(board3); }, true, x -> Boolean.TRUE.equals(x)); // EDGE CASE
        System.out.println(passed + " / 3 cases cleared");
    }

    interface Checker { boolean matches(Object actual); }
    interface ThrowingSupplier { Object get() throws Throwable; }
    static void runTest(int n, ThrowingSupplier supplier, Object expected, Checker checker) {
        try {
            Object actual = supplier.get();
            boolean ok = checker.matches(actual);
            System.out.println("testcase " + n + ": " + (ok ? "pass" : "fail"));
            if (!ok) {
                System.out.println("expected output: " + display(expected));
                System.out.println("your output: " + display(actual));
            }
            if (ok) passed++;
        } catch (Throwable e) {
            System.out.println("testcase " + n + ": fail");
            System.out.println("expected output: " + display(expected));
            System.out.println("your output: exception " + e.getClass().getSimpleName());
        }
    }

    static String display(Object x) {
        if (x instanceof int[]) return Arrays.toString((int[])x);
        if (x instanceof long[]) return Arrays.toString((long[])x);
        if (x instanceof Object[]) return Arrays.deepToString((Object[])x);
        return String.valueOf(x);
    }
    static boolean sameIntArray(Object actual,Object expected){ return Arrays.equals((int[])actual,(int[])expected); }
    static boolean validTimingArray(Object actual,Object expected){ long[] a=(long[])actual; return a.length==2 && a[0]>=0 && a[1]>=0; }
    static boolean validZeroTimingArray(Object actual,Object expected){ long[] a=(long[])actual; return Arrays.equals(a,new long[]{0L,0L}); }
    static boolean employeeOrder(List<?> x){ if(x.size()!=5)return false; return x.get(0).toString().equals("Anu|HR|85000") && x.get(1).toString().equals("Amit|HR|85000") && x.get(2).toString().equals("Bob|IT|120000") && x.get(3).toString().equals("Cara|IT|120000") && x.get(4).toString().equals("Zara|IT|90000"); }
    static boolean employeeTieOrder(List<?> x){ return x.size()==3 && x.get(0).toString().startsWith("Amy|") && x.get(1).toString().startsWith("Ben|") && x.get(2).toString().startsWith("Zed|"); }
    static boolean isSolved(char[][] b){ for(int r=0;r<9;r++){ boolean[] row=new boolean[10], col=new boolean[10]; for(int c=0;c<9;c++){ char rc=b[r][c], cc=b[c][r]; if(rc<'1'||rc>'9'||row[rc-'0']) return false; if(cc<'1'||cc>'9'||col[cc-'0']) return false; row[rc-'0']=true; col[cc-'0']=true; } } for(int br=0;br<9;br+=3) for(int bc=0;bc<9;bc+=3){ boolean[] seen=new boolean[10]; for(int r=br;r<br+3;r++) for(int c=bc;c<bc+3;c++){ int d=b[r][c]-'0'; if(d<1||d>9||seen[d]) return false; seen[d]=true; } } return true; }
}