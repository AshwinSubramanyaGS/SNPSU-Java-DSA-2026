# Sudoku Solver

Given a partially-filled 9x9 Sudoku board, fill the empty cells so that every row, column and 3x3 box contains digits 1-9 exactly once.

Empty cells contain '.'. Return the same board after solving.

Assume the provided puzzle has exactly one solution. Use backtracking with validity checks.

## Method
`Solution.void solveSudoku(char[][] board)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
