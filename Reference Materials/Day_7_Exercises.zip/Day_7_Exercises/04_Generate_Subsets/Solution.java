import java.util.*;

public class Solution {
    public static List<List<Integer>> subsets(int[] nums) {
        // implement here
        return new ArrayList<>();
    }
}