# Generate All Permutations

Given an array of distinct integers, return all permutations using backtracking.

The output order does not matter. Each permutation must contain every input value exactly once.

Example: [1,2] -> [1,2] and [2,1].

## Method
`Solution.List<List<Integer>> permutations(int[] nums)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
