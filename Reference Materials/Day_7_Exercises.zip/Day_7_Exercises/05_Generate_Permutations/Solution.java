import java.util.*;

public class Solution {
    public static List<List<Integer>> permutations(int[] nums) {
        // implement here
        return new ArrayList<>();
    }
}