public class Solution {
    public static int[] mergeSort(int[] nums) {
        // implement here
        return nums;
    }
}