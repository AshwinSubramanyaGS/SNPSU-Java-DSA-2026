public class Solution {
    public static double power(double x, int n) {
        // implement here
        return 0.0;
    }
}