# Fast Power Using Recursion

Compute x^n using recursive exponentiation by squaring.

Requirements:
- Average recursion depth should be O(log n).
- Support negative exponents.
- Return a double.

Examples: power(2,10)=1024.0, power(2,-2)=0.25.

## Method
`Solution.double power(double x, int n)`

## Expectations
Solve the problem in `Solution.java`. Run `Main.java` to validate your implementation. Every group of three cases contains one explicitly marked edge case.
