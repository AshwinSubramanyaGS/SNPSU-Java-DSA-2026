public class Solution {
    static class Node {
        int value; Node next;
        Node(int value) { this.value = value; }
    }

    public static Node merge(Node a, Node b) { /* implement */ return a; }
    public static int[] toArray(Node head) { /* implement */ return new int[0]; }
}
